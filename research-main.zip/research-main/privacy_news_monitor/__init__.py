"""Privacy News Monitor - 개인정보 보호 동향 모니터링 서비스"""

__version__ = "1.0.0"
